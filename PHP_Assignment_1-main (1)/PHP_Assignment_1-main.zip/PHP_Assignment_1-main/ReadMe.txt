Assignment 1: 

Completed by: Rowan Lajoie & Emmanuel Aigbokhan

This is a sample ReadMe.txt
